export class Loan {
    constructor(public loanid:number,
                //public accountno:Account
                public type:String,
                public amount:String,
                public tenure:number,
                public interest:number,
                

    ){}
}
