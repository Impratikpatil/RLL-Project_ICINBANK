import { Userregister } from './userregister';

describe('Userregister', () => {
  it('should create an instance', () => {
    expect(new Userregister()).toBeTruthy();
  });
});
