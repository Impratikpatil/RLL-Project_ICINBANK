import { Admin } from './admin';

describe('Admin', () => {
  it('should have the correct email and password', () => {
    const admin = new Admin('admin@example.com', 'admin');
    
    expect(admin.email).toEqual('admin@example.com');
    expect(admin.password).toEqual('admin');
  });
});
