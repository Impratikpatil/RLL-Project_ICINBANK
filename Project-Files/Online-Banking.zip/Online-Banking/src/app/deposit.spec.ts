import { Deposit } from './deposit';

describe('Deposit', () => {
  it('should create an instance', () => {
    expect(new Deposit()).toBeTruthy();
  });
});
