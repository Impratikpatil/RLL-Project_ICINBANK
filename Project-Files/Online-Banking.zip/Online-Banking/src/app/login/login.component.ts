import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserregService } from '../userreg.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
loginRef = new FormGroup({
  email : new FormControl(),
  password: new FormControl()
});
 

msg:string = ""
  constructor(public lgs:UserregService, public router:Router) { }
  goToPage(pageName:string):void{
    this.router.navigate([`${pageName}`]);
  }

  ngOnInit(): void {
  }
  signIn() {
  const login = this.loginRef.value;
  const adminEmail = "admin@example.com"; // Replace with the actual admin email
  const adminPassword = "admin"; // Replace with the actual admin password (securely stored)

  if (login.email === adminEmail && login.password === adminPassword) {
    // Admin login
    this.lgs.signinadmin(login).subscribe({
      next: (result: any) => {
        console.log(result);
        if (result === "successful") {
          sessionStorage.setItem("email", login.email);
          this.router.navigate(["admindashboard"]);
        } else {
          this.msg = result;
        }
      },
      error: (error: any) => console.log(error),
      complete: () => console.log("Admin login completed")
    });
  } else {
    // Regular user login
    this.lgs.signinuser(login).subscribe({
      next: (result: any) => {
        console.log(result);
        if (result === "successful") {
          // Fetch user ID and set session variables
          this.lgs.getid(login.email).subscribe({
            next: (value) => {
              sessionStorage.setItem("email", login.email);
              sessionStorage.setItem("userid", value);
            },
            error: (err) => console.log(err),
            complete: () => console.log("User ID fetched")
          });
          this.router.navigate(["userdashboard"]);
        } else {
          this.msg = result;
        }
      },
      error: (error: any) => console.log(error),
      complete: () => console.log("Regular user login completed")
    });
  }
}


}
