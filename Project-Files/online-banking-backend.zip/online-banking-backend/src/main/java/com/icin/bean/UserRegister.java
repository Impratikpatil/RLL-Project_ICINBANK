package com.icin.bean;

public class UserRegister {
    private User user;
    private Account account;

    public UserRegister() {
        this.user = user;
        this.account = account;
    }

    public Account getAccount() {
    	Account account = new Account();  // Create an instance of the Account class or retrieve it from somewhere
        // Perform any necessary logic to populate the account object
        
        return account;

    }
    public User getUser() {
    	User user = new User();  // Create an instance of the User class or retrieve it from somewhere
        // Perform any necessary logic to populate the user object
        
        return user;
    }
    // Getters and setters for user and account

	public void setUser(User user2) {
		// TODO Auto-generated method stub
		
	}

	public void setAccount(Account account2) {
		// TODO Auto-generated method stub
		
	}
}
