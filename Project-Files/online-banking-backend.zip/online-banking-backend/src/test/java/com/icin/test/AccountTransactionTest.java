package com.icin.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.icin.bean.AccountTransaction;
import com.icin.bean.Account;
import com.icin.bean.Transaction;

public class AccountTransactionTest {

    private AccountTransaction accountTransaction;

    @BeforeEach
    public void setUp() {
        // Initialize the AccountTransaction instance before each test
        accountTransaction = new AccountTransaction();
    }

    @Test
    public void testGettersAndSetters() {
        // Test getters and setters
        Account account = new Account(); // Replace with an actual Account instance
        Transaction transaction = new Transaction(); // Replace with an actual Transaction instance

        accountTransaction.setAccount(account);
        accountTransaction.setTransaction(transaction);

        assertEquals(account, accountTransaction.getAccount());
        assertEquals(transaction, accountTransaction.getTransaction());
    }

    @Test
    public void testToString() {
        // Test the toString() method
        assertNotNull(accountTransaction.toString());
    }
}
