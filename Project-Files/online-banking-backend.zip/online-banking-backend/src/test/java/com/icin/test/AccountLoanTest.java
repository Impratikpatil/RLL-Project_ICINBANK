package com.icin.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.icin.bean.AccountLoan;
import com.icin.bean.Loan;

public class AccountLoanTest {

    private AccountLoan accountLoan;

    @BeforeEach
    public void setUp() {
        // Initialize the AccountLoan instance before each test
        accountLoan = new AccountLoan();
    }

    @Test
    public void testGettersAndSetters() {
        // Test getters and setters
        Loan loan = new Loan(); // Replace with an actual Loan instance
        int accountNo = 12345;

        accountLoan.setLoan(loan);
        accountLoan.setAccountno(accountNo);

        assertEquals(loan, accountLoan.getLoan());
        assertEquals(accountNo, accountLoan.getAccountno());
    }

    @Test
    public void testToString() {
        // Test the toString() method
        assertNotNull(accountLoan.toString());
    }
}
