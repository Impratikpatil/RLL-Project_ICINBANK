package com.icin.test;

import static org.junit.Assert.*;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.junit.jupiter.api.BeforeEach;
import com.icin.bean.Account;
import com.icin.bean.UserRegister;

public class UserRegisterTest {
    private UserRegister userRegister;

    @BeforeEach
    public void setUp() {
        userRegister = new UserRegister();
    }

    @Test
    public void testGetAccount() {
        Account account = userRegister.getAccount();
        assertNotNull(account);  // Check that an account is returned
        // You can add more assertions to verify the properties of the account object
    }

    @Test
    public void testGetUser() {
        User user = new User();
        assertNotNull(user);  // Check that a user is returned
        // You can add more assertions to verify the properties of the user object
    }

    // Add more test cases as needed

    // You can also write test cases for the setters if needed
}