package com.icin.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.icin.bean.Account;
import com.icin.bean.User;
import com.icin.bean.Loan;
import com.icin.bean.Transaction;

public class AccountTest {

    private Account account;

    @BeforeEach
    public void setUp() {
        // Initialize the Account instance before each test
        account = new Account();
    }

    @Test
    public void testGettersAndSetters() {
        // Test getters and setters for basic properties
        long accountNo = 12345L;
        User user = new User(); // Replace with an actual User instance
        List<Loan> loans = new ArrayList<>(); // Replace with actual Loan instances
        List<Transaction> transactions = new ArrayList<>(); // Replace with actual Transaction instances
        float balance = 1000.0f;

        account.setAccountno(accountNo);
        account.setUserid(user);
        account.setLoanid(loans);
        account.setTransactionid(transactions);
        account.setBalance(balance);
        account.setAccounttype("savings");
        account.setTransfer("active");
        account.setDeposit("active");
        account.setWithdrawl("active");
        account.setCheque("active");
        account.setStatus("active");
        account.setLoanstatus("pending");

        assertEquals(accountNo, account.getAccountno());
        assertEquals(user, account.getUserid());
        assertEquals(loans, account.getLoanid());
        assertEquals(transactions, account.getTransactionid());
        assertEquals(balance, account.getBalance(), 0.01); // Allow small difference due to float precision
        assertEquals("savings", account.getAccounttype());
        assertEquals("active", account.getTransfer());
        assertEquals("active", account.getDeposit());
        assertEquals("active", account.getWithdrawl());
        assertEquals("active", account.getCheque());
        assertEquals("active", account.getStatus());
        assertEquals("pending", account.getLoanstatus());
    }

    @Test
    public void testToString() {
        // Test the toString() method
        assertNotNull(account.toString());
    }
}
