package com.icin.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.icin.bean.Transaction;
import com.icin.bean.Account;

public class TransactionTest {

    private Transaction transaction;

    @BeforeEach
    public void setUp() {
        // Initialize the Transaction instance before each test
        transaction = new Transaction();
    }

    @Test
    public void testGettersAndSetters() {
        // Test getters and setters
        Integer transactionId = 1;
        Account account = new Account(); // Replace with an actual Account instance
        LocalDateTime timestamp = LocalDateTime.now();
        int recipientNo = 2;
        String recipientName = "John Doe";
        float amount = 500.0f;

        transaction.setTransactionid(transactionId);
        transaction.setAccountno(account);
        transaction.setTimestamp(timestamp);
        transaction.setRecepientno(recipientNo);
        transaction.setRecipient_name(recipientName);
        transaction.setAmount(amount);

        assertEquals(transactionId, transaction.getTransactionid());
        assertEquals(account, transaction.getAccountno());
        assertEquals(timestamp, transaction.getTimestamp());
        assertEquals(recipientNo, transaction.getRecepientno());
        assertEquals(recipientName, transaction.getRecipient_name());
        assertEquals(amount, transaction.getAmount(), 0.01); // Allow small difference due to float precision
    }

    @Test
    public void testToString() {
        // Test the toString() method
        assertNotNull(transaction.toString());
    }
}
