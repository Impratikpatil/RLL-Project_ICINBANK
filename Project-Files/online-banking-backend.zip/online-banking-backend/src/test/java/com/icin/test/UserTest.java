package com.icin.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.icin.bean.User;
import com.icin.bean.Account;

public class UserTest {

    private User user;

    @BeforeEach
    public void setUp() {
        // Initialize the User instance before each test
        user = new User();
    }

    @Test
    public void testGettersAndSetters() {
        // Test getters and setters
        int userId = 1;
        List<Account> accounts = new ArrayList<>(); // Replace with actual Account instances
        String email = "user@example.com";
        String password = "securePassword";
        String address = "123 Main St";
        String transactionPassword = "transactionPassword";
        String name = "John Doe";
        long phoneNumber = 1234567890;
        long panNumber = 1234567890;
        Date date = new Date();

        user.setUserid(userId);
        user.setAccountno(accounts);
        user.setEmail(email);
        user.setPassword(password);
        user.setAddress(address);
        user.setTransactionpassword(transactionPassword);
        user.setName(name);
        user.setPhno(phoneNumber);
        user.setPanno(panNumber);
        user.setDate(date);

        assertEquals(userId, user.getUserid());
        assertEquals(accounts, user.getAccountno());
        assertEquals(email, user.getEmail());
        assertEquals(password, user.getPassword());
        assertEquals(address, user.getAddress());
        assertEquals(transactionPassword, user.getTransactionpassword());
        assertEquals(name, user.getName());
        assertEquals(phoneNumber, user.getPhno());
        assertEquals(panNumber, user.getPanno());
        assertEquals(date, user.getDate());
    }

    @Test
    public void testToString() {
        // Test the toString() method
        assertNotNull(user.toString());
    }
}
