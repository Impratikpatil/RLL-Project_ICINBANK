package com.icin.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.icin.bean.Loan;
import com.icin.bean.Account;

public class LoanTest {

    private Loan loan;

    @BeforeEach
    public void setUp() {
        // Initialize the Loan instance before each test
        loan = new Loan();
    }

    @Test
    public void testGettersAndSetters() {
        // Test getters and setters
        long loanId = 1L;
        Account account = new Account(); // Replace with an actual Account instance
        String type = "Home Loan";
        String amount = "1000000";
        int tenure = 120;
        int interest = 5;

        loan.setLoanid(loanId);
        loan.setAccountno(account);
        loan.setType(type);
        loan.setAmount(amount);
        loan.setTenure(tenure);
        loan.setInterest(interest);

        assertEquals(loanId, loan.getLoanid());
        assertEquals(account, loan.getAccountno());
        assertEquals(type, loan.getType());
        assertEquals(amount, loan.getAmount());
        assertEquals(tenure, loan.getTenure());
        assertEquals(interest, loan.getInterest());
    }

    @Test
    public void testConstructor() {
        // Test constructor
        long loanId = 1L;
        Account account = new Account(); // Replace with an actual Account instance
        String type = "Home Loan";
        String amount = "1000000";
        int tenure = 120;
        int interest = 5;

        Loan loan = new Loan(loanId, account, type, amount, tenure, interest);

        assertEquals(loanId, loan.getLoanid());
        assertEquals(account, loan.getAccountno());
        assertEquals(type, loan.getType());
        assertEquals(amount, loan.getAmount());
        assertEquals(tenure, loan.getTenure());
        assertEquals(interest, loan.getInterest());
    }

    @Test
    public void testToString() {
        // Test the toString() method
        assertNotNull(loan.toString());
    }
}
