package com.icin.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.icin.bean.Admin;

public class AdminTest {

    private Admin admin;

    @BeforeEach
    public void setUp() {
        // Initialize the Admin instance before each test
        admin = new Admin();
    }

    public void testGettersAndSetters() {
        // Test getters and setters
        String email = "admin@example.com";
        String password = "securePassword";

        admin.setEmail(email);
        admin.setPassword(password);

        assertEquals(email, admin.getEmail());
        assertEquals(password, admin.getPassword());
    }

    @Test
    public void testToString() {
        // Test the toString() method
        assertNotNull(admin.toString());
    }
}
